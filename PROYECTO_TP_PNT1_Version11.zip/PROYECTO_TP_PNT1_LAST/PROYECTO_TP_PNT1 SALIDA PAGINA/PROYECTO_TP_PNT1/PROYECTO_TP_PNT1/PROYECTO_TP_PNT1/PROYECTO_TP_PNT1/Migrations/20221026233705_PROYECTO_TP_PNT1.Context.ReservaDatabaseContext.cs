﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PROYECTO_TP_PNT1.Migrations
{
    public partial class PROYECTO_TP_PNT1ContextReservaDatabaseContext : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Alojamientos",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(nullable: true),
                    direccion = table.Column<string>(nullable: true),
                    cantHabitacionesDisponibles = table.Column<int>(nullable: false),
                    tipo = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Alojamientos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Reservas",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    entrada = table.Column<DateTime>(nullable: false),
                    salida = table.Column<DateTime>(nullable: false),
                    precio = table.Column<double>(nullable: false),
                    confirmado = table.Column<bool>(nullable: false),
                    desayuno = table.Column<bool>(nullable: false),
                    cantPersonas = table.Column<int>(nullable: false),
                    CantHabitaciones = table.Column<int>(nullable: false),
                    alojamientoid = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservas", x => x.id);
                    table.ForeignKey(
                        name: "FK_Reservas_Alojamientos_alojamientoid",
                        column: x => x.alojamientoid,
                        principalTable: "Alojamientos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Clientes",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(nullable: true),
                    apellido = table.Column<string>(nullable: true),
                    dni = table.Column<string>(nullable: true),
                    edad = table.Column<int>(nullable: false),
                    reservaid = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clientes", x => x.id);
                    table.ForeignKey(
                        name: "FK_Clientes_Reservas_reservaid",
                        column: x => x.reservaid,
                        principalTable: "Reservas",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Clientes_reservaid",
                table: "Clientes",
                column: "reservaid");

            migrationBuilder.CreateIndex(
                name: "IX_Reservas_alojamientoid",
                table: "Reservas",
                column: "alojamientoid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Clientes");

            migrationBuilder.DropTable(
                name: "Reservas");

            migrationBuilder.DropTable(
                name: "Alojamientos");
        }
    }
}
