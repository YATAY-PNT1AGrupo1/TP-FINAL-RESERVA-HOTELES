﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PROYECTO_TP_PNT1.Context;
using PROYECTO_TP_PNT1.Models;

namespace PROYECTO_TP_PNT1.Controllers
{
    public class ReservaController : Controller
    {
        private readonly ReservaDatabaseContext _context;

        public ReservaController(ReservaDatabaseContext context)
        {
            _context = context;
        }

        // GET: Reserva
        public async Task<IActionResult> Index()
        {
            var ReservaDBContext = _context.Reservas.Include(e => e.alojamiento).Include(e => e.cliente);
            return View(await _context.Reservas.ToListAsync());
        }

        // GET: Reserva/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reserva = await _context.Reservas
                .Include(e => e.alojamiento)
                .Include(e => e.cliente)
                .FirstOrDefaultAsync(m => m.idReserva == id);

            if (reserva == null)
            {
                return NotFound();
            }

            return View(reserva);
        }

        // GET: Reserva/Create
        public IActionResult Create()

        {
            List<int> cliente = new List<int>();
            cliente = (from Cliente c in _context.Clientes select c.idCliente).ToList<int>();
            

            List<int> alojamiento = new List<int>();
            alojamiento = (from Alojamiento a in _context.Alojamientos select a.idAlojamiento).ToList<int>();

            ViewBag.Alojamiento = alojamiento;
            ViewBag.Clientes = cliente;
            return View();
        }
      
        // POST: Reserva/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("entrada,salida, cliente, alojamiento, cantPersonas, cantHabitaciones, desayuno")] Reserva reserva)
        {

            if (ModelState.IsValid)
            {
               
                //antes del add armar un metodo que le pasemos por parametro el objeto reserva, y dentro del metodo hay que tomar el dbContextDeReserva
                //hacer lo que esta en el pdf en la pagina dos. es decir hay que hacer una consulta a la reserva, y ver si existe. si existe no se hace el add.

                if (!ReservaExists(reserva.idReserva))
                {
                   
                    reserva.alojamiento = _context.Alojamientos.Find(reserva.idAlojamiento);
                    
                    _context.Add(reserva);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
        
             
            }
            
            return View(reserva);
        }

        // GET: Reserva/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reserva = await _context.Reservas.FindAsync(id);
            if (reserva == null)
            {
                return NotFound();
            }
            ViewData["AlojamientoID"] = new SelectList(_context.Alojamientos, "IdAlojamiento", "nombre", reserva.idAlojamiento);
            ViewData["ClienteId"] = new SelectList(_context.Clientes, "IdCliente", "apellido", reserva.idCliente);
            return View(reserva);
        }

        // POST: Reserva/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,entrada,salida,precio,confirmado,desayuno,cantPersonas,CantHabitaciones, idAlojamiento, idCliente")] Reserva reserva)
        {
            if (id != reserva.idReserva)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(reserva);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReservaExists(reserva.idReserva))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AlojamientoID"] = new SelectList(_context.Alojamientos, "IdAlojamiento", "nombre", reserva.idAlojamiento);
            ViewData["ClienteId"] = new SelectList(_context.Clientes, "IdCliente", "apellido", reserva.idCliente);
            return View(reserva);
        }

        // GET: Reserva/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reserva = await _context.Reservas
                 .Include(e => e.alojamiento)
                 .Include(e => e.cliente)
                 .FirstOrDefaultAsync(m => m.idReserva == id);
            if (reserva == null)
            {
                return NotFound();
            }

            return View(reserva);
        }

        // POST: Reserva/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reserva = await _context.Reservas.FindAsync(id);
            _context.Reservas.Remove(reserva);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReservaExists(int id)
        {
            return _context.Reservas.Any(e => e.idReserva == id);
        }
    }
}
