﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PROYECTO_TP_PNT1.Models
{
    public class Alojamiento
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        
        public int idAlojamiento { get; set; }

        [DataType(DataType.Text)]
        [Display(Name = "Nombre")]
        [Required(ErrorMessage = "El nombre es obligatorio.")]
        public string nombre { get; set; }

        [DataType(DataType.Text)]
        [Display(Name = "Direccion")]
        [Required(ErrorMessage = "La direccion es obligatoria.")]
        public string direccion{ get; set; }

        [Display(Name = "Habitaciones disponibles")]
        public int cantHabitacionesDisponibles { get; set; }
        [EnumDataType(typeof(TipoDeAlojamiento))]
        [Display(Name = "Alojamiento de tipo")]
        public TipoDeAlojamiento tipo { get; set; }

        [Display(Name = "Precio")]
        public double precio { get; set; }

    }
}
