﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PROYECTO_TP_PNT1.Models
{
    public enum TipoDeAlojamiento
    {
        HOTEL,
        APART,
        HOSTEL,
        CABAÑA


    }
}
